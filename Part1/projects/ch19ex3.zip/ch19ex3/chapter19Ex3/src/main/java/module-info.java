module chapter19Ex3 {
    requires javafx.controls;
	requires javafx.graphics;
    requires java.sql;
    exports chapter19Ex3;
}
